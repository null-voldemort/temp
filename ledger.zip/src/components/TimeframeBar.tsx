import React from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { addDays, dhakaMonth, dhakaToday, type TimeframeMode } from '../utils/ledger';

interface Props {
  mode: TimeframeMode;
  onModeChange: (m: TimeframeMode) => void;
  anchorDate: string;
  onAnchorDateChange: (d: string) => void;
  anchorMonth: string;
  onAnchorMonthChange: (ym: string) => void;
  anchorYear: string;
  onAnchorYearChange: (y: string) => void;
  customFrom: string;
  customTo: string;
  onCustomChange: (from: string, to: string) => void;
  rangeLabel: string;
}

const MODES: { id: TimeframeMode; label: string }[] = [
  { id: 'daily', label: 'Daily' },
  { id: 'weekly', label: 'Weekly' },
  { id: 'monthly', label: 'Monthly' },
  { id: 'yearly', label: 'Yearly' },
  { id: 'custom', label: 'Custom' },
];

function stepMonth(ym: string, delta: number): string {
  const [y, m] = ym.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}`;
}

export const TimeframeBar: React.FC<Props> = ({
  mode,
  onModeChange,
  anchorDate,
  onAnchorDateChange,
  anchorMonth,
  onAnchorMonthChange,
  anchorYear,
  onAnchorYearChange,
  customFrom,
  customTo,
  onCustomChange,
  rangeLabel,
}) => {
  const step = (dir: -1 | 1) => {
    if (mode === 'daily') onAnchorDateChange(addDays(anchorDate, dir));
    else if (mode === 'weekly') onAnchorDateChange(addDays(anchorDate, dir * 7));
    else if (mode === 'monthly') onAnchorMonthChange(stepMonth(anchorMonth, dir));
    else if (mode === 'yearly') onAnchorYearChange(String((Number(anchorYear) || 2026) + dir));
  };

  const resetToCurrent = () => {
    const today = dhakaToday();
    onAnchorDateChange(today);
    onAnchorMonthChange(dhakaMonth());
    onAnchorYearChange(today.slice(0, 4));
  };

  return (
    <div className="flex flex-wrap items-center gap-2.5">
      <div className="inline-flex items-center gap-1 p-1 rounded-xl bg-slate-100 border border-slate-200/70">
        {MODES.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => onModeChange(m.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              mode === m.id ? 'bg-white text-brand-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {mode !== 'custom' ? (
        <div className="inline-flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2 py-1 shadow-xs">
          <button
            type="button"
            onClick={() => step(-1)}
            aria-label="Previous period"
            className="w-7 h-7 grid place-items-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {mode === 'monthly' ? (
            <input
              type="month"
              value={anchorMonth}
              onChange={(e) => e.target.value && onAnchorMonthChange(e.target.value)}
              aria-label="Select month"
              className="text-xs font-semibold text-[#1b2a4e] bg-transparent focus:outline-none px-1 tabular-nums"
            />
          ) : mode === 'yearly' ? (
            <input
              type="number"
              min={2020}
              max={2099}
              value={anchorYear}
              onChange={(e) => onAnchorYearChange(e.target.value)}
              aria-label="Select year"
              className="w-20 text-center text-xs font-semibold text-[#1b2a4e] bg-transparent focus:outline-none tabular-nums"
            />
          ) : (
            <label className="inline-flex items-center gap-1.5 px-1 text-xs font-semibold text-[#1b2a4e] cursor-pointer">
              <Calendar className="w-3.5 h-3.5 text-brand-600" />
              <input
                type="date"
                value={anchorDate}
                onChange={(e) => e.target.value && onAnchorDateChange(e.target.value)}
                aria-label="Select date"
                className="text-xs font-semibold text-[#1b2a4e] bg-transparent focus:outline-none tabular-nums"
              />
            </label>
          )}

          <button
            type="button"
            onClick={() => step(1)}
            aria-label="Next period"
            className="w-7 h-7 grid place-items-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={resetToCurrent}
            className="ml-1 px-2 py-1 rounded-lg text-[11px] font-semibold text-brand-700 hover:bg-brand-50 transition-colors"
          >
            Today
          </button>
        </div>
      ) : (
        <div className="inline-flex flex-wrap items-center gap-1.5 bg-white border border-slate-200 rounded-xl px-2.5 py-1.5 shadow-xs text-xs">
          <span className="text-slate-500 font-medium">From</span>
          <input
            type="date"
            value={customFrom}
            onChange={(e) => onCustomChange(e.target.value, customTo)}
            className="font-semibold text-[#1b2a4e] bg-transparent focus:outline-none tabular-nums"
          />
          <span className="text-slate-400">→</span>
          <span className="text-slate-500 font-medium">To</span>
          <input
            type="date"
            value={customTo}
            onChange={(e) => onCustomChange(customFrom, e.target.value)}
            className="font-semibold text-[#1b2a4e] bg-transparent focus:outline-none tabular-nums"
          />
        </div>
      )}

      <span className="text-xs font-medium text-slate-500">{rangeLabel}</span>
    </div>
  );
};

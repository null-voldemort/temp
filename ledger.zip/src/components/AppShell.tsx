import React, { useCallback, useEffect, useState } from 'react';
import { Menu } from 'lucide-react';
import { Sidebar, type SidebarProps } from './Sidebar';
import { DevelopedBy } from './DevelopedBy';

const DESKTOP_QUERY = '(min-width: 1024px)';

type ShellSidebarProps = Omit<SidebarProps, 'visible' | 'isDesktop' | 'onClose' | 'onToggle'>;

interface AppShellProps extends ShellSidebarProps {
  children: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({ children, ...sidebarProps }) => {
  const [isDesktop, setIsDesktop] = useState(() => window.matchMedia(DESKTOP_QUERY).matches);
  const [desktopOpen, setDesktopOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia(DESKTOP_QUERY);
    const sync = () => setIsDesktop(mq.matches);
    sync();
    mq.addEventListener('change', sync);
    return () => mq.removeEventListener('change', sync);
  }, []);

  const toggle = useCallback(() => {
    if (isDesktop) setDesktopOpen((v) => !v);
    else setMobileOpen((v) => !v);
  }, [isDesktop]);
  const close = useCallback(() => setMobileOpen(false), []);
  const open = useCallback(() => setMobileOpen(true), []);

  return (
    <div className="flex-1 flex min-w-0">
      <Sidebar
        {...sidebarProps}
        visible={isDesktop ? desktopOpen : mobileOpen}
        isDesktop={isDesktop}
        onClose={close}
        onToggle={toggle}
      />

      <div className="flex-1 min-w-0 flex flex-col @container/main">
        <header className="lg:hidden no-print sticky top-0 z-30 h-14 px-4 bg-[#eef8f1]/90 backdrop-blur-md border-b border-slate-200/70 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={open}
            aria-label="Open menu"
            className="grid place-items-center w-9 h-9 rounded-xl bg-white border border-slate-200 text-[#1b2a4e]"
          >
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-display text-lg font-bold text-brand-700">
            Pace <span className="text-brand-500">IT</span> Ledger
          </span>
          <div className="w-9" aria-hidden="true" />
        </header>

        {children}

        <DevelopedBy />
      </div>
    </div>
  );
};

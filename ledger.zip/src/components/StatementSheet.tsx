import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Copy,
  Download,
  Edit3,
  FileSpreadsheet,
  Lock,
  Plus,
  Printer,
  Search,
} from 'lucide-react';
import type { LedgerHead, LedgerKind, LedgerTransaction, PeriodLock } from '../types';
import {
  computeRange,
  dhakaMonth,
  dhakaToday,
  formatShortDate,
  summarizePeriod,
  type TimeframeMode,
} from '../utils/ledger';
import { formatBDT } from '../utils/money';
import { exportSummaryExcel, exportSummaryPdf } from '../utils/exportLedger';
import { lockPeriod } from '../utils/cloud';
import { TimeframeBar } from './TimeframeBar';

interface Props {
  transactions: LedgerTransaction[];
  heads: LedgerHead[];
  locks: PeriodLock[];
  isAdmin: boolean;
  onOpenTx: (tx: LedgerTransaction) => void;
  onAddTx: (kind: LedgerKind, head?: string) => void;
  onEditTx?: (tx: LedgerTransaction) => void;
  onDuplicateTx?: (tx: LedgerTransaction) => void;
  onLocksChanged: () => void;
  onToast: (msg: string) => void;
}

const INK = 'text-[#1b2a4e]';
const SURFACE = 'bg-white rounded-3xl border border-slate-100 shadow-[0_12px_32px_-16px_rgba(30,50,110,0.22)]';

export const StatementSheet: React.FC<Props> = ({
  transactions,
  heads,
  locks,
  isAdmin,
  onOpenTx,
  onAddTx,
  onEditTx,
  onDuplicateTx,
  onLocksChanged,
  onToast,
}) => {
  const [mode, setMode] = useState<TimeframeMode>('monthly');
  const [anchorDate, setAnchorDate] = useState(dhakaToday);
  const [anchorMonth, setAnchorMonth] = useState(dhakaMonth);
  const [anchorYear, setAnchorYear] = useState(() => dhakaToday().slice(0, 4));
  const [customFrom, setCustomFrom] = useState(dhakaToday);
  const [customTo, setCustomTo] = useState(dhakaToday);
  const [selectedBucket, setSelectedBucket] = useState<{ kind: LedgerKind; head: string } | null>(null);
  const [drillSearch, setDrillSearch] = useState('');
  const [locking, setLocking] = useState(false);

  const range = useMemo(
    () => computeRange(mode, anchorDate, anchorMonth, anchorYear, customFrom, customTo),
    [mode, anchorDate, anchorMonth, anchorYear, customFrom, customTo],
  );

  const summary = useMemo(
    () => summarizePeriod(transactions, heads, range.from, range.to, range.label),
    [transactions, heads, range],
  );

  const activeLock = useMemo(
    () => (mode === 'monthly' ? locks.find((l) => l.periodKey === anchorMonth) : undefined),
    [locks, mode, anchorMonth],
  );

  const drillTransactions = useMemo(() => {
    const q = drillSearch.trim().toLowerCase();
    return summary.periodTransactions.filter((t) => {
      if (selectedBucket && (t.kind !== selectedBucket.kind || t.head !== selectedBucket.head)) return false;
      if (!q) return true;
      return [t.voucherNo, t.head, t.counterparty, t.paymentMethod, t.referenceNo, t.purpose, t.notes]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .includes(q);
    });
  }, [summary.periodTransactions, selectedBucket, drillSearch]);

  const handleLockMonth = async () => {
    if (mode !== 'monthly') return;
    setLocking(true);
    try {
      await lockPeriod(anchorMonth, `Signed off monthly statement for ${summary.label}`);
      onLocksChanged();
      onToast(`${summary.label} signed off & locked`);
    } catch (e: any) {
      onToast(e?.message || 'Could not lock period');
    } finally {
      setLocking(false);
    }
  };

  return (
    <div className="max-w-[1400px] mx-auto px-4 @md:px-6 @5xl:px-8 py-6 space-y-5">
      
      <div className={`${SURFACE} p-5 @md:p-6`}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="grid place-items-center w-9 h-9 rounded-xl bg-brand-50 text-brand-700 shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </span>
              <h1 className={`font-display text-xl @md:text-2xl font-extrabold tracking-tight ${INK}`}>
                INCOME &amp; EXPENSE STATEMENT — {summary.label.toUpperCase()}
              </h1>
              {activeLock && (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700">
                  · <Lock className="w-3.5 h-3.5" /> Locked by {activeLock.lockedByName}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Click any channel or office row below to inspect every Taka, method, receipt, and edit trail behind the total.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 no-print">
            {isAdmin && mode === 'monthly' && !activeLock && (
              <button
                type="button"
                disabled={locking}
                onClick={handleLockMonth}
                className="h-9 px-3.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold inline-flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <Lock className="w-3.5 h-3.5" /> Sign Off &amp; Lock Month
              </button>
            )}
            <button
              type="button"
              onClick={() => exportSummaryExcel(summary)}
              className="h-9 px-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-[#1b2a4e] inline-flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-brand-600" /> Excel
            </button>
            <button
              type="button"
              onClick={() => exportSummaryPdf(summary)}
              className="h-9 px-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-[#1b2a4e] inline-flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-rose-600" /> PDF
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="h-9 px-3.5 rounded-xl bg-[#1b2a4e] hover:bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" /> Print
            </button>
          </div>
        </div>

        
        <div className="mt-5 grid grid-cols-2 @3xl:grid-cols-5 gap-3 pt-4 border-t border-slate-100">
          <div className="rounded-2xl bg-slate-50 px-3.5 py-2.5">
            <div className="text-[11px] font-semibold text-slate-400">Previous Balance</div>
            <div className={`text-base font-extrabold tabular-nums mt-0.5 ${INK}`}>{formatBDT(summary.openingBalancePaisa)}</div>
          </div>
          <div className="rounded-2xl bg-emerald-50/70 px-3.5 py-2.5">
            <div className="text-[11px] font-semibold text-emerald-700">Period Income</div>
            <div className="text-base font-extrabold tabular-nums text-emerald-700 mt-0.5">{formatBDT(summary.periodIncomePaisa)}</div>
          </div>
          <div className="rounded-2xl bg-brand-50/70 px-3.5 py-2.5">
            <div className="text-[11px] font-semibold text-brand-800">Total Available (INCOME)</div>
            <div className="text-base font-extrabold tabular-nums text-brand-800 mt-0.5">{formatBDT(summary.totalAvailablePaisa)}</div>
          </div>
          <div className="rounded-2xl bg-amber-50/70 px-3.5 py-2.5">
            <div className="text-[11px] font-semibold text-amber-800">Total Expense</div>
            <div className="text-base font-extrabold tabular-nums text-amber-800 mt-0.5">{formatBDT(summary.periodExpensePaisa)}</div>
          </div>
          <div className={`rounded-2xl px-3.5 py-2.5 col-span-2 @3xl:col-span-1 ${summary.closingBalancePaisa < 0 ? 'bg-rose-50' : 'bg-[#1b2a4e] text-white'}`}>
            <div className={`text-[11px] font-semibold ${summary.closingBalancePaisa < 0 ? 'text-rose-700' : 'text-white/75'}`}>Closing Balance</div>
            <div className={`text-base font-extrabold tabular-nums mt-0.5 ${summary.closingBalancePaisa < 0 ? 'text-rose-700' : 'text-white'}`}>
              {formatBDT(summary.closingBalancePaisa)}
            </div>
          </div>
        </div>
      </div>

      
      <div className="no-print">
        <TimeframeBar
          mode={mode}
          onModeChange={setMode}
          anchorDate={anchorDate}
          onAnchorDateChange={setAnchorDate}
          anchorMonth={anchorMonth}
          onAnchorMonthChange={setAnchorMonth}
          anchorYear={anchorYear}
          onAnchorYearChange={setAnchorYear}
          customFrom={customFrom}
          customTo={customTo}
          onCustomChange={(f, t) => { setCustomFrom(f); setCustomTo(t); }}
          rangeLabel={range.label}
        />
      </div>

      
      <div className="grid grid-cols-1 @4xl:grid-cols-2 gap-5 items-start">
        
        <section className={`${SURFACE} overflow-hidden`}>
          <div className="px-5 py-3.5 bg-[#1b2a4e] text-white flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
              <h2 className="text-sm font-bold tracking-wide uppercase">INCOME</h2>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-base font-extrabold tabular-nums">{formatBDT(summary.totalAvailablePaisa)}</span>
              <button
                type="button"
                onClick={() => onAddTx('income')}
                className="no-print h-7 px-2.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-semibold inline-flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-4 py-2.5 text-left">Channel / Details</th>
                  <th className="px-3 py-2.5 text-center w-20">Entries</th>
                  <th className="px-4 py-2.5 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr className="bg-slate-50/50">
                  <td className={`px-4 py-2.5 font-semibold ${INK}`}>Previous Period (Opening)</td>
                  <td className="px-3 py-2.5 text-center text-xs text-slate-400">Carry-fwd</td>
                  <td className={`px-4 py-2.5 text-right font-bold tabular-nums ${INK}`}>
                    {formatBDT(summary.openingBalancePaisa)}
                  </td>
                </tr>
                {summary.incomeByHead.map((row) => {
                  const selected = selectedBucket?.kind === 'income' && selectedBucket.head === row.head;
                  return (
                    <tr
                      key={row.head}
                      onClick={() => setSelectedBucket(selected ? null : { kind: 'income', head: row.head })}
                      className={`cursor-pointer transition-colors ${selected ? 'bg-brand-50' : 'hover:bg-slate-50/80'}`}
                    >
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold ${INK}`}>{row.head}</span>
                          {row.editedCount > 0 && (
                            <span className="text-[11px] font-semibold text-amber-600 inline-flex items-center gap-0.5">
                              · {row.editedCount} edited
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-center text-xs text-slate-500 tabular-nums">{row.count}</td>
                      <td className={`px-4 py-2.5 text-right font-bold tabular-nums ${row.totalPaisa > 0 ? 'text-brand-700' : 'text-slate-400'}`}>
                        {formatBDT(row.totalPaisa)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-emerald-50/60 border-t-2 border-emerald-200">
                <tr>
                  <td className="px-4 py-3 font-extrabold text-emerald-900">TOTAL AVAILABLE INCOME</td>
                  <td className="px-3 py-3 text-center text-xs font-bold text-emerald-800 tabular-nums">
                    {summary.periodTransactions.filter((t) => t.kind === 'income').length}
                  </td>
                  <td className="px-4 py-3 text-right font-extrabold text-emerald-800 tabular-nums">
                    {formatBDT(summary.totalAvailablePaisa)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>

        
        <section className={`${SURFACE} overflow-hidden`}>
          <div className="px-5 py-3.5 bg-[#1b2a4e] text-white flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ArrowUpRight className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold tracking-wide uppercase">EXPENSE</h2>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-base font-extrabold tabular-nums">{formatBDT(summary.periodExpensePaisa)}</span>
              <button
                type="button"
                onClick={() => onAddTx('expense')}
                className="no-print h-7 px-2.5 rounded-lg bg-white/15 hover:bg-white/25 text-xs font-semibold inline-flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-4 py-2.5 text-left">Office / Details</th>
                  <th className="px-3 py-2.5 text-center w-20">Entries</th>
                  <th className="px-4 py-2.5 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {summary.expenseByHead.map((row) => {
                  const selected = selectedBucket?.kind === 'expense' && selectedBucket.head === row.head;
                  return (
                    <tr
                      key={row.head}
                      onClick={() => setSelectedBucket(selected ? null : { kind: 'expense', head: row.head })}
                      className={`cursor-pointer transition-colors ${selected ? 'bg-brand-50' : 'hover:bg-slate-50/80'}`}
                    >
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold ${INK}`}>{row.head}</span>
                          {row.editedCount > 0 && (
                            <span className="text-[11px] font-semibold text-amber-600 inline-flex items-center gap-0.5">
                              · {row.editedCount} edited
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-center text-xs text-slate-500 tabular-nums">{row.count}</td>
                      <td className={`px-4 py-2.5 text-right font-bold tabular-nums ${row.totalPaisa > 0 ? INK : 'text-slate-400'}`}>
                        {formatBDT(row.totalPaisa)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-amber-50/60 border-t-2 border-amber-200">
                <tr>
                  <td className="px-4 py-3 font-extrabold text-amber-900">TOTAL EXPENSE</td>
                  <td className="px-3 py-3 text-center text-xs font-bold text-amber-800 tabular-nums">
                    {summary.periodTransactions.filter((t) => t.kind === 'expense').length}
                  </td>
                  <td className="px-4 py-3 text-right font-extrabold text-amber-900 tabular-nums">
                    {formatBDT(summary.periodExpensePaisa)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>
      </div>

      
      <section className={`${SURFACE} overflow-hidden`}>
        <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className={`text-sm font-bold ${INK}`}>
              {selectedBucket
                ? `${selectedBucket.head} — ${selectedBucket.kind === 'income' ? 'Income' : 'Expense'} Breakdown (${drillTransactions.length})`
                : `Every Entry in ${summary.label} (${drillTransactions.length})`}
            </h2>
            <p className="text-xs text-slate-500">
              {selectedBucket
                ? 'Showing itemized vouchers inside this head. Click Show All to view the full period.'
                : 'Select any channel or office row above to isolate its transactions, or click a voucher for full edit history.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 no-print">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={drillSearch}
                onChange={(e) => setDrillSearch(e.target.value)}
                placeholder="Search voucher, payee, ref, reason..."
                className="h-9 pl-8 pr-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-500"
              />
            </div>
            {selectedBucket && (
              <>
                <button
                  type="button"
                  onClick={() => onAddTx(selectedBucket.kind, selectedBucket.head)}
                  className="h-9 px-3 rounded-xl bg-brand-700 hover:bg-brand-800 text-white text-xs font-semibold inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add to {selectedBucket.head}
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedBucket(null)}
                  className="h-9 px-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                >
                  Show All
                </button>
              </>
            )}
          </div>
        </div>

        {drillTransactions.length === 0 ? (
          <div className="px-6 py-10 text-center text-xs text-slate-400">
            No transactions match this selection in {summary.label}.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 border-b border-slate-100 text-left text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-4 py-2.5">Voucher / Date</th>
                  <th className="px-4 py-2.5">Head &amp; Category</th>
                  <th className="px-4 py-2.5">How (Method &amp; Ref)</th>
                  <th className="px-4 py-2.5">From / Where &amp; Why</th>
                  <th className="px-4 py-2.5">Audit</th>
                  <th className="px-4 py-2.5 text-right">Amount</th>
                  {(onEditTx || onDuplicateTx) && <th className="px-3 py-2.5 text-right no-print">Quick</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {drillTransactions.map((tx) => (
                  <tr
                    key={tx.id}
                    onClick={() => onOpenTx(tx)}
                    className="cursor-pointer hover:bg-slate-50/90 transition-colors"
                  >
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className={`font-mono font-bold ${INK}`}>{tx.voucherNo}</div>
                      <div className="text-[11px] text-slate-400 tabular-nums">{formatShortDate(tx.txDate)}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className={`font-semibold ${INK}`}>{tx.head}</div>
                      <div className="text-[11px] text-slate-500">
                        {tx.subCategory}
                        {tx.department ? <span className="ml-1.5 text-slate-400">· {tx.department}</span> : null}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-700">{tx.paymentMethod}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{tx.referenceNo || 'No ref'}</div>
                    </td>
                    <td className="px-4 py-3 max-w-md">
                      <div className={`font-semibold truncate ${INK}`}>{tx.counterparty}</div>
                      <div className="text-[11px] text-slate-500 line-clamp-2">{tx.purpose}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {tx.status === 'flagged' ? (
                        <span className="font-bold text-rose-600 inline-flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Flagged
                        </span>
                      ) : tx.editCount > 0 ? (
                        <span className="font-semibold text-amber-700">
                          {tx.editCount} edit{tx.editCount === 1 ? '' : 's'}
                          {tx.amountChanged ? ' (amount)' : ''}
                        </span>
                      ) : (
                        <span className="text-slate-400">Original</span>
                      )}
                    </td>
                    <td className={`px-4 py-3 text-right font-bold tabular-nums whitespace-nowrap ${tx.kind === 'income' ? 'text-brand-700' : 'text-rose-600'}`}>
                      {tx.kind === 'income' ? '+' : '-'}{formatBDT(tx.amountPaisa)}
                    </td>
                    {(onEditTx || onDuplicateTx) && (
                      <td className="px-3 py-3 text-right whitespace-nowrap no-print" onClick={(e) => e.stopPropagation()}>
                        <div className="inline-flex items-center gap-1">
                          {onEditTx && (
                            <button
                              type="button"
                              onClick={() => onEditTx(tx)}
                              title="Edit voucher"
                              aria-label={`Edit ${tx.voucherNo}`}
                              className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 hover:text-[#1b2a4e] inline-grid place-items-center transition-colors"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {onDuplicateTx && (
                            <button
                              type="button"
                              onClick={() => onDuplicateTx(tx)}
                              title="Repeat / clone entry"
                              aria-label={`Repeat ${tx.voucherNo}`}
                              className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-brand-50 text-slate-600 hover:text-brand-700 inline-grid place-items-center transition-colors"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};

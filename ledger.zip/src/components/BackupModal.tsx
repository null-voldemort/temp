import React, { useState } from 'react';
import { Database, Download, Upload, X } from 'lucide-react';
import { downloadFullBackup, restoreFullBackup } from '../utils/cloud';
import { DatabaseWipeCard } from './DatabaseWipeCard';
import { ScrollLock } from './ScrollLock';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  isAdmin: boolean;
  onRestored: () => void;
  onFactoryReset?: () => void;
  onToast: (msg: string) => void;
}

export const BackupModal: React.FC<Props> = ({ isOpen, onClose, isAdmin, onRestored, onFactoryReset, onToast }) => {
  const [parsedBackup, setParsedBackup] = useState<any>(null);
  const [fileName, setFileName] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleDownload = async () => {
    setBusy(true);
    setError('');
    try {
      await downloadFullBackup();
      onToast('Full ledger backup downloaded');
    } catch (err: any) {
      setError(err?.message || 'Backup export failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setError('');
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const json = JSON.parse(String(reader.result || ''));
        if (!json || json.format !== 'pace-it-ledger-backup' || !json.tables) {
          setError('Selected file is not a valid Pace IT Ledger full backup.');
          setParsedBackup(null);
          return;
        }
        setParsedBackup(json);
        setFileName(file.name);
      } catch {
        setError('Could not parse JSON backup file.');
        setParsedBackup(null);
      }
    };
    reader.readAsText(file);
  };

  const handleRestore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!parsedBackup) return;
    setBusy(true);
    setError('');
    try {
      await restoreFullBackup(parsedBackup, password);
      onRestored();
      onToast('Backup restored — reloading data');
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Restore failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="no-print fixed inset-0 z-[75] flex items-center justify-center p-3 sm:p-6 bg-slate-950/60 backdrop-blur-sm">
      <ScrollLock />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Database Backup and Restore"
        className="bg-white w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl border border-slate-100 p-6 space-y-4"
      >
        <div className="flex items-center gap-3">
          <span className="grid place-items-center w-10 h-10 rounded-2xl bg-brand-50 text-brand-700">
            <Database className="w-5 h-5" />
          </span>
          <div>
            <h2 className="text-base font-bold text-[#1b2a4e]">Database &amp; Backup</h2>
            <p className="text-xs text-slate-500">Export, restore, or reset the ledger, staff, receipts, and hash chain.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="ml-auto grid place-items-center w-9 h-9 rounded-full text-slate-400 hover:bg-slate-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && <div className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2 text-xs text-rose-700">{error}</div>}

        <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4 flex items-center justify-between gap-3">
          <div>
            <div className="text-sm font-bold text-[#1b2a4e]">Download Full JSON Backup</div>
            <div className="text-xs text-slate-500">Includes all transactions, staff, loans, voucher photos, and audit chain.</div>
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={handleDownload}
            className="shrink-0 h-10 px-4 rounded-xl bg-brand-700 hover:bg-brand-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-50"
          >
            <Download className="w-4 h-4" /> Download
          </button>
        </div>

        {isAdmin && (
          <>
            <form onSubmit={handleRestore} className="rounded-2xl border border-amber-200 bg-amber-50/50 p-4 space-y-3">
              <div>
                <div className="text-sm font-bold text-[#1b2a4e]">Restore from Full Backup (Admin Only)</div>
                <div className="text-xs text-slate-600">Replaces current database tables with the uploaded snapshot.</div>
              </div>
              <label className="h-10 px-3.5 rounded-xl border border-dashed border-amber-300 bg-white flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                <Upload className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="truncate">{fileName || 'Choose pace-it-ledger-backup-*.json'}</span>
                <input type="file" accept="application/json,.json" onChange={handleFile} className="hidden" />
              </label>
              {parsedBackup && (
                <>
                  <input
                    type="password"
                    required
                    placeholder="Confirm your Admin password to restore"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-10 px-3 text-xs bg-white border border-amber-300 rounded-xl"
                  />
                  <button disabled={busy} className="w-full h-10 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold disabled:opacity-50">
                    {busy ? 'Restoring...' : 'Restore Database Snapshot'}
                  </button>
                </>
              )}
            </form>

            <DatabaseWipeCard
              onWiped={() => { onRestored(); onClose(); }}
              onFactoryReset={() => { onClose(); onFactoryReset?.(); }}
              onToast={onToast}
            />
          </>
        )}
      </div>
    </div>
  );
};

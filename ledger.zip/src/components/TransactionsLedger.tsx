import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Camera,
  Check,
  Copy,
  Download,
  Edit3,
  Paperclip,
  Plus,
  Search,
} from 'lucide-react';
import type { DepartmentRecord, Employee, FundSource, LedgerHead, LedgerKind, LedgerTransaction } from '../types';
import {
  EXPENSE_PURPOSES,
  INCOME_PURPOSES,
  PAYMENT_METHODS,
  computeRange,
  dhakaMonth,
  dhakaToday,
  formatShortDate,
  type TimeframeMode,
} from '../utils/ledger';
import { formatBDT, toPaisa } from '../utils/money';
import { exportTransactionsExcel } from '../utils/exportLedger';
import { createTransaction } from '../utils/cloud';
import { CameraCaptureModal } from './CameraCaptureModal';
import { ComboInput } from './ComboInput';
import { TimeframeBar } from './TimeframeBar';

interface Props {
  transactions: LedgerTransaction[];
  heads: LedgerHead[];
  departments: DepartmentRecord[];
  employees: Employee[];
  fundSources: FundSource[];
  onOpenTx: (tx: LedgerTransaction) => void;
  onAddTx: (kind: LedgerKind) => void;
  onEditTx?: (tx: LedgerTransaction) => void;
  onDuplicateTx?: (tx: LedgerTransaction) => void;
  onOpenEmployee?: (emp: Employee) => void;
  onQuickSaved: (tx: LedgerTransaction) => void;
  onToast: (msg: string) => void;
}

const INK = 'text-[#1b2a4e]';
const SURFACE = 'bg-white rounded-3xl border border-slate-100 shadow-[0_12px_32px_-16px_rgba(30,50,110,0.22)]';

export const TransactionsLedger: React.FC<Props> = ({
  transactions,
  heads,
  departments,
  employees,
  fundSources,
  onOpenTx,
  onAddTx,
  onEditTx,
  onDuplicateTx,
  onOpenEmployee,
  onQuickSaved,
  onToast,
}) => {
  const [usePeriod, setUsePeriod] = useState(false);
  const [mode, setMode] = useState<TimeframeMode>('monthly');
  const [anchorDate, setAnchorDate] = useState(dhakaToday);
  const [anchorMonth, setAnchorMonth] = useState(dhakaMonth);
  const [anchorYear, setAnchorYear] = useState(() => dhakaToday().slice(0, 4));
  const [customFrom, setCustomFrom] = useState(dhakaToday);
  const [customTo, setCustomTo] = useState(dhakaToday);

  const [kindFilter, setKindFilter] = useState<'all' | LedgerKind>('all');
  const [headFilter, setHeadFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [methodFilter, setMethodFilter] = useState('all');
  const [auditFilter, setAuditFilter] = useState<'all' | 'edited' | 'amount_changed' | 'flagged' | 'receipt' | 'unclassified_dept'>('all');
  const [search, setSearch] = useState('');

  const activeIncomeHeads = useMemo(() => heads.filter((h) => h.kind === 'income' && h.active), [heads]);
  const activeExpenseHeads = useMemo(() => heads.filter((h) => h.kind === 'expense' && h.active), [heads]);
  const activeDepartments = useMemo(() => departments.filter((d) => d.active), [departments]);
  const activeEmployees = useMemo(() => employees.filter((e) => e.active), [employees]);

  const [qDate, setQDate] = useState(dhakaToday);
  const [qKind, setQKind] = useState<LedgerKind | ''>('');
  const [qDepartment, setQDepartment] = useState('');
  const [qHead, setQHead] = useState('');
  const [qSubCategory, setQSubCategory] = useState('');
  const [qFundSourceId, setQFundSourceId] = useState('');
  const [qEmpId, setQEmpId] = useState('');
  const [qAmount, setQAmount] = useState('');
  const [qMethod, setQMethod] = useState('');
  const [qRef, setQRef] = useState('');
  const [qCounterparty, setQCounterparty] = useState('');
  const [qPurpose, setQPurpose] = useState('');
  const [qReceipt, setQReceipt] = useState<{ name: string; data: string } | undefined>(undefined);
  const [qCameraOpen, setQCameraOpen] = useState(false);
  const [qBusy, setQBusy] = useState(false);

  const switchQuickKind = (next: LedgerKind | '') => {
    setQKind(next);
    setQHead('');
    setQSubCategory('');
  };

  const handleQuickEmp = (nextId: string) => setQEmpId(nextId);

  const handleQuickSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const paisa = toPaisa(qAmount);
    if (!qKind || !qDepartment.trim() || !qFundSourceId || !qHead.trim() || !qSubCategory.trim() || !qMethod.trim() || !qCounterparty.trim() || qPurpose.trim().length < 2) {
      onToast('Complete all required fields, including type, department, and funding source.');
      return;
    }
    if (!paisa || paisa <= 0) {
      onToast('Enter a valid quick-entry amount.');
      return;
    }
    const emp = activeEmployees.find((x) => x.id === qEmpId);
    setQBusy(true);
    try {
      const saved = await createTransaction({
        kind: qKind,
        txDate: qDate,
        amount: qAmount,
        department: qDepartment.trim(),
        head: qHead.trim(),
        subCategory: qSubCategory.trim(),
        paymentMethod: qMethod.trim(),
        referenceNo: qRef.trim(),
        counterparty: qCounterparty.trim(),
        counterpartyPhone: emp?.phone || '',
        purpose: qPurpose.trim(),
        employeeId: emp?.id,
        employeeName: emp?.name,
        categoryGroup: 'general',
        fundSourceId: qFundSourceId,
        receipt: qReceipt,
      });
      setQKind('');
      setQDepartment('');
      setQHead('');
      setQSubCategory('');
      setQFundSourceId('');
      setQEmpId('');
      setQAmount('');
      setQMethod('');
      setQRef('');
      setQCounterparty('');
      setQPurpose('');
      setQReceipt(undefined);
      onQuickSaved(saved);
    } catch (err: any) {
      onToast(err?.message || 'Could not save entry.');
    } finally {
      setQBusy(false);
    }
  };

  const handleQuickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setQReceipt({ name: file.name, data: reader.result });
    };
    reader.readAsDataURL(file);
  };

  const range = useMemo(
    () => computeRange(mode, anchorDate, anchorMonth, anchorYear, customFrom, customTo),
    [mode, anchorDate, anchorMonth, anchorYear, customFrom, customTo],
  );

  const unclassifiedDept = useMemo(() => {
    const rows = transactions.filter((t) => !t.deletedAt && (t.departmentReview || !t.department?.trim()));
    const totalPaisa = rows.reduce((s, t) => s + t.amountPaisa, 0);
    return { count: rows.length, totalPaisa };
  }, [transactions]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return transactions
      .filter((t) => !t.deletedAt)
      .filter((t) => {
        if (usePeriod && (t.txDate < range.from || t.txDate > range.to)) return false;
        if (kindFilter !== 'all' && t.kind !== kindFilter) return false;
        if (headFilter !== 'all' && t.head !== headFilter) return false;
        if (departmentFilter !== 'all') {
          if (departmentFilter === '__none__') {
            if (t.department && !t.departmentReview) return false;
          } else if (t.department !== departmentFilter) {
            return false;
          }
        }
        if (methodFilter !== 'all' && t.paymentMethod !== methodFilter) return false;
        if (auditFilter === 'edited' && t.editCount === 0) return false;
        if (auditFilter === 'amount_changed' && !t.amountChanged) return false;
        if (auditFilter === 'flagged' && t.status !== 'flagged') return false;
        if (auditFilter === 'receipt' && !t.receiptSha) return false;
        if (auditFilter === 'unclassified_dept' && !t.departmentReview && Boolean(t.department?.trim())) return false;
        if (!q) return true;
        return [
          t.voucherNo,
          t.txDate,
          t.department,
          t.head,
          t.subCategory,
          t.paymentMethod,
          t.referenceNo,
          t.counterparty,
          t.employeeName,
          t.purpose,
          t.notes,
          t.createdByName,
          t.lastEditReason,
          t.fundSourceName,
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase()
          .includes(q);
      });
  }, [transactions, usePeriod, range, kindFilter, headFilter, departmentFilter, methodFilter, auditFilter, search]);

  const totals = useMemo(() => {
    let inc = 0;
    let exp = 0;
    for (const t of filtered) {
      if (t.kind === 'income') inc += t.amountPaisa;
      else exp += t.amountPaisa;
    }
    return { inc, exp, net: inc - exp };
  }, [filtered]);

  const uniqueHeadNames = useMemo(() => {
    const set = new Set<string>(heads.map((h) => h.name));
    transactions.forEach((t) => t.head && set.add(t.head));
    return Array.from(set);
  }, [heads, transactions]);

  const uniqueDepartmentNames = useMemo(() => {
    const set = new Set<string>(departments.map((d) => d.name));
    transactions.forEach((t) => t.department && set.add(t.department));
    return Array.from(set);
  }, [departments, transactions]);

  const uniqueMethodNames = useMemo(() => {
    const set = new Set<string>(PAYMENT_METHODS);
    transactions.forEach((t) => t.paymentMethod && set.add(t.paymentMethod));
    return Array.from(set);
  }, [transactions]);

  const uniqueSubCategoryNames = useMemo(() => {
    const defaults = qKind === 'income' ? INCOME_PURPOSES : qKind === 'expense' ? EXPENSE_PURPOSES : [];
    const set = new Set<string>(defaults);
    transactions.forEach((t) => {
      if (qKind && t.kind === qKind && t.subCategory) set.add(t.subCategory);
    });
    return Array.from(set);
  }, [transactions, qKind]);

  const selectCls =
    'h-9 px-3 text-xs font-semibold text-[#1b2a4e] bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-500';
  const qInputCls =
    'h-9 px-2.5 text-xs text-[#1b2a4e] bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-500 w-full';
  const qHeadOptions = useMemo(() => {
    const list = (qKind === 'income' ? activeIncomeHeads : qKind === 'expense' ? activeExpenseHeads : []).map((h) => h.name);
    const set = new Set<string>(list);
    transactions.forEach((t) => {
      if (qKind && t.kind === qKind && t.head) set.add(t.head);
    });
    return Array.from(set);
  }, [qKind, activeIncomeHeads, activeExpenseHeads, transactions]);

  return (
    <div className="max-w-[1400px] mx-auto px-4 @md:px-6 @5xl:px-8 py-6 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className={`font-display text-2xl font-extrabold tracking-tight ${INK}`}>Daily Ledger</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Record transactions with mandatory department, channel/office, funding source, and voucher photos.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => exportTransactionsExcel(filtered, usePeriod ? range.label : 'Daily-Ledger')}
            className="h-9 px-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-[#1b2a4e] inline-flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-brand-600" /> Export Excel ({filtered.length})
          </button>
          <button
            type="button"
            onClick={() => onAddTx('income')}
            className="h-9 px-3.5 rounded-xl bg-brand-700 hover:bg-brand-800 text-white text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Record Income
          </button>
          <button
            type="button"
            onClick={() => onAddTx('expense')}
            className="h-9 px-3.5 rounded-xl bg-[#1b2a4e] hover:bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Record Expense
          </button>
        </div>
      </div>

      {unclassifiedDept.count > 0 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50/80 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5 min-w-0">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900">
              <span className="font-bold">Department Reconciliation Needed:</span>{' '}
              {unclassifiedDept.count} entries totaling <b className="tabular-nums">{formatBDT(unclassifiedDept.totalPaisa)}</b> do not have a department assigned yet.
            </div>
          </div>
          <button
            type="button"
            onClick={() => setAuditFilter((cur) => (cur === 'unclassified_dept' ? 'all' : 'unclassified_dept'))}
            className={`h-8 px-3 rounded-xl text-xs font-bold border transition-colors shrink-0 ${
              auditFilter === 'unclassified_dept'
                ? 'bg-amber-600 border-amber-600 text-white'
                : 'bg-white border-amber-300 text-amber-900 hover:bg-amber-100'
            }`}
          >
            {auditFilter === 'unclassified_dept' ? 'Show All Entries' : `Review ${unclassifiedDept.count} Unclassified`}
          </button>
        </div>
      )}

      <form onSubmit={handleQuickSave} className={`${SURFACE} p-4 space-y-2.5`}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-[#1b2a4e]">Quick Inline Entry</span>
          <span className="text-[11px] text-slate-400">
            {qReceipt ? `Voucher attached: ${qReceipt.name}` : 'Department, channel/office, method, and funding source are required'}
          </span>
        </div>

        <div className="grid grid-cols-1 @md:grid-cols-2 @3xl:grid-cols-5 gap-2">
          <input type="date" value={qDate} onChange={(e) => setQDate(e.target.value)} className={`${qInputCls} tabular-nums`} aria-label="Date" />
          <select value={qKind} onChange={(e) => switchQuickKind(e.target.value as LedgerKind | '')} className={qInputCls} aria-label="Type">
            <option value="">Select transaction type *</option>
            <option value="expense">Expense (Out)</option>
            <option value="income">Income (In)</option>
          </select>
          <select value={qDepartment} onChange={(e) => setQDepartment(e.target.value)} required className={qInputCls} aria-label="Department">
            <option value="">Select department *</option>
            {activeDepartments.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
          </select>
          <ComboInput
            value={qHead}
            onChange={setQHead}
            options={qHeadOptions}
            required
            ariaLabel="Channel or Office"
            placeholder={qKind === 'income' ? 'Channel / Source *' : 'Office / Field *'}
            className={qInputCls}
          />
          <ComboInput
            value={qSubCategory}
            onChange={setQSubCategory}
            options={uniqueSubCategoryNames}
            required
            ariaLabel="Field Category"
            placeholder="Category / Field *"
            className={qInputCls}
          />

          <input
            type="text"
            inputMode="decimal"
            required
            value={qAmount}
            onChange={(e) => setQAmount(e.target.value)}
            placeholder="Amount ৳ *"
            className={`${qInputCls} font-mono font-bold tabular-nums`}
          />
          <ComboInput
            value={qMethod}
            onChange={setQMethod}
            options={uniqueMethodNames}
            required
            ariaLabel="Payment Method"
            placeholder="Method (Cash, bKash, ATM...)"
            className={qInputCls}
          />
          <select value={qFundSourceId} onChange={(e) => setQFundSourceId(e.target.value)} required className={qInputCls} aria-label="Funding source">
            <option value="">Select fund source *</option>
            {fundSources.filter((source) => source.active).map((source) => <option key={source.id} value={source.id}>{source.name}</option>)}
          </select>
          <select value={qEmpId} onChange={(e) => handleQuickEmp(e.target.value)} className={qInputCls} aria-label="Employee">
            <option value="">Staff (Optional)</option>
            {activeEmployees.map((emp) => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
          </select>
          <input
            type="text"
            value={qCounterparty}
            onChange={(e) => setQCounterparty(e.target.value)}
            placeholder={qKind === 'income' ? 'Received From *' : 'Paid To / Vendor *'}
            className={qInputCls}
          />
        </div>

        <div className="grid grid-cols-1 @3xl:grid-cols-[1fr_12rem_auto] gap-2 items-center pt-0.5">
          <input
            type="text"
            value={qPurpose}
            onChange={(e) => setQPurpose(e.target.value)}
            placeholder="Why / Details *"
            className={qInputCls}
          />
          <input
            type="text"
            value={qRef}
            onChange={(e) => setQRef(e.target.value)}
            placeholder="Ref / Slip # (Optional)"
            className={`${qInputCls} font-mono`}
          />
          <div className="flex flex-wrap items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setQCameraOpen(true)}
              className="h-9 px-3 rounded-xl border border-brand-200 bg-brand-50 hover:bg-brand-100 text-xs font-semibold text-brand-900 inline-flex items-center gap-1.5"
            >
              <Camera className="w-3.5 h-3.5" /> Photo
            </button>
            <label className="h-9 px-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white text-xs font-semibold text-[#1b2a4e] inline-flex items-center gap-1.5 cursor-pointer">
              <Paperclip className="w-3.5 h-3.5 text-brand-600" />
              <span>{qReceipt ? 'Replace' : 'Attach'}</span>
              <input type="file" accept="image/jpeg,image/png,application/pdf" onChange={handleQuickFile} className="hidden" />
            </label>
            <button
              type="submit"
              disabled={qBusy}
              className="h-9 px-4 rounded-xl bg-brand-700 hover:bg-brand-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-60"
            >
              <Check className="w-3.5 h-3.5" /> {qBusy ? 'Saving...' : 'Save Quick Entry'}
            </button>
          </div>
        </div>
      </form>

      <div className={`${SURFACE} p-4 space-y-3`}>
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search voucher, department, employee, payee/sender, ref #..."
              className="w-full h-9 pl-9 pr-3 text-xs text-[#1b2a4e] bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-brand-500"
            />
          </div>

          <select value={kindFilter} onChange={(e) => setKindFilter(e.target.value as any)} className={selectCls}>
            <option value="all">All Types</option>
            <option value="income">Income Only</option>
            <option value="expense">Expense Only</option>
          </select>

          <select value={departmentFilter} onChange={(e) => setDepartmentFilter(e.target.value)} className={selectCls}>
            <option value="all">All Departments</option>
            <option value="__none__">Unclassified Department</option>
            {uniqueDepartmentNames.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>

          <select value={headFilter} onChange={(e) => setHeadFilter(e.target.value)} className={selectCls}>
            <option value="all">All Channels &amp; Offices</option>
            {uniqueHeadNames.map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>

          <select value={methodFilter} onChange={(e) => setMethodFilter(e.target.value)} className={selectCls}>
            <option value="all">All Methods</option>
            {uniqueMethodNames.map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          <select value={auditFilter} onChange={(e) => setAuditFilter(e.target.value as any)} className={selectCls}>
            <option value="all">All Audit States</option>
            <option value="unclassified_dept">Needs Department Review</option>
            <option value="edited">Edited Entries</option>
            <option value="amount_changed">Amount Altered</option>
            <option value="flagged">Flagged for Review</option>
            <option value="receipt">Has Voucher Photo</option>
          </select>

          <button
            type="button"
            onClick={() => setUsePeriod((v) => !v)}
            className={`h-9 px-3 rounded-xl text-xs font-semibold border transition-colors ${
              usePeriod ? 'bg-brand-50 border-brand-200 text-brand-900' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {usePeriod ? `Date Filter: ${range.label}` : 'All Dates'}
          </button>
        </div>

        {usePeriod && (
          <TimeframeBar
            mode={mode}
            onModeChange={setMode}
            anchorDate={anchorDate}
            onAnchorDateChange={setAnchorDate}
            anchorMonth={anchorMonth}
            onAnchorMonthChange={setAnchorMonth}
            anchorYear={anchorYear}
            onAnchorYearChange={setAnchorYear}
            customFrom={customFrom}
            customTo={customTo}
            onCustomChange={(f, t) => { setCustomFrom(f); setCustomTo(t); }}
            rangeLabel={range.label}
          />
        )}

        <div className="flex flex-wrap items-center gap-x-6 gap-y-1 pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-500">
            Showing <b className={INK}>{filtered.length}</b> transactions
          </span>
          <span className="text-emerald-700 font-semibold tabular-nums">
            Filtered Income: {formatBDT(totals.inc)}
          </span>
          <span className="text-rose-600 font-semibold tabular-nums">
            Filtered Expense: {formatBDT(totals.exp)}
          </span>
          <span className={`font-bold tabular-nums ${totals.net < 0 ? 'text-rose-600' : INK}`}>
            Net: {formatBDT(totals.net)}
          </span>
        </div>
      </div>

      <section className={`${SURFACE} overflow-hidden`}>
        {filtered.length === 0 ? (
          <div className="px-6 py-14 text-center text-sm text-slate-400">
            No transactions match your current filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 border-b border-slate-100 text-left text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="px-4 py-3">Voucher &amp; Date</th>
                  <th className="px-4 py-3">Dept / Head</th>
                  <th className="px-4 py-3">Method &amp; Ref #</th>
                  <th className="px-4 py-3">Party / Staff &amp; Why</th>
                  <th className="px-4 py-3">Entered By / Trail</th>
                  <th className="px-4 py-3 text-right">Amount</th>
                  {(onEditTx || onDuplicateTx) && <th className="px-3 py-3 text-right no-print">Quick</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((tx) => {
                  const linkedEmp = tx.employeeId ? employees.find((e) => e.id === tx.employeeId) : undefined;
                  const needsDept = tx.departmentReview || !tx.department?.trim();
                  return (
                    <tr
                      key={tx.id}
                      onClick={() => onOpenTx(tx)}
                      className="cursor-pointer hover:bg-slate-50/90 transition-colors"
                    >
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          {tx.kind === 'income' ? (
                            <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          ) : (
                            <ArrowUpRight className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                          )}
                          <span className={`font-mono font-bold ${INK}`}>{tx.voucherNo}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 tabular-nums pl-5">{formatShortDate(tx.txDate)}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className={`font-semibold ${INK}`}>{tx.head}</div>
                        <div className="text-[11px] text-slate-500">
                          {tx.subCategory}
                          {needsDept ? (
                            <span className="ml-1.5 text-amber-700 font-semibold">· Dept pending</span>
                          ) : (
                            <span className="ml-1.5 text-slate-400">· {tx.department}</span>
                          )}
                        </div>
                        <div className="text-[10px] text-brand-700">Fund: {tx.fundSourceName || 'Unassigned'}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-slate-700">{tx.paymentMethod}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {tx.referenceNo || '—'}
                          {tx.receiptSha && (
                            <span className="ml-2 text-brand-700 inline-flex items-center gap-0.5 font-sans">
                              <Paperclip className="w-3 h-3" /> Photo
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 max-w-md">
                        <div className="flex items-center gap-1.5">
                          <span className={`font-semibold truncate ${INK}`}>{tx.counterparty}</span>
                          {linkedEmp && onOpenEmployee && (
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); onOpenEmployee(linkedEmp); }}
                              className="text-[11px] font-semibold text-brand-700 hover:underline shrink-0"
                            >
                              · {linkedEmp.code}
                            </button>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 line-clamp-2">{tx.purpose}</div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="text-slate-600">{tx.createdByName}</div>
                        {tx.status === 'flagged' ? (
                          <div className="text-[11px] font-bold text-rose-600 inline-flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" /> Flagged
                          </div>
                        ) : tx.editCount > 0 ? (
                          <div className="text-[11px] font-semibold text-amber-700">
                            {tx.editCount} edit{tx.editCount === 1 ? '' : 's'}{tx.amountChanged ? ' · amount changed' : ''}
                          </div>
                        ) : (
                          <div className="text-[11px] text-slate-400">Original</div>
                        )}
                      </td>
                      <td className={`px-4 py-3 text-right font-extrabold tabular-nums whitespace-nowrap ${tx.kind === 'income' ? 'text-brand-700' : 'text-rose-600'}`}>
                        {tx.kind === 'income' ? '+' : '-'}{formatBDT(tx.amountPaisa)}
                      </td>
                      {(onEditTx || onDuplicateTx) && (
                        <td className="px-3 py-3 text-right whitespace-nowrap no-print" onClick={(e) => e.stopPropagation()}>
                          <div className="inline-flex items-center gap-1">
                            {onEditTx && (
                              <button
                                type="button"
                                onClick={() => onEditTx(tx)}
                                title="Edit voucher"
                                aria-label={`Edit ${tx.voucherNo}`}
                                className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 hover:text-[#1b2a4e] inline-grid place-items-center transition-colors"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            {onDuplicateTx && (
                              <button
                                type="button"
                                onClick={() => onDuplicateTx(tx)}
                                title="Repeat / clone entry"
                                aria-label={`Repeat ${tx.voucherNo}`}
                                className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-brand-50 text-slate-600 hover:text-brand-700 inline-grid place-items-center transition-colors"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <CameraCaptureModal
        isOpen={qCameraOpen}
        onClose={() => setQCameraOpen(false)}
        onCapture={(file) => setQReceipt(file)}
      />
    </div>
  );
};

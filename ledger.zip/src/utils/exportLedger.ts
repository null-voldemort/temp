import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { LedgerTransaction } from '../types';
import type { PeriodSummary } from './ledger';
import { fromPaisa } from './money';

const pdfNum = (paisa: number) => {
  const n = Math.round(paisa || 0);
  const abs = Math.abs(n);
  const whole = Math.floor(abs / 100).toLocaleString('en-US');
  const cents = String(abs % 100).padStart(2, '0');
  return `${n < 0 ? '-' : ''}BDT ${whole}.${cents}`;
};

export function exportSummaryExcel(summary: PeriodSummary) {
  const wb = XLSX.utils.book_new();

   
  const maxRows = Math.max(summary.incomeByHead.length + 1, summary.expenseByHead.length);
  const sheetRows: (string | number)[][] = [
    ['PACE IT — INCOME & EXPENSE STATEMENT', '', '', '', '', ''],
    ['Period:', summary.label, `${summary.from} to ${summary.to}`, '', 'Closing Balance (BDT):', Number(fromPaisa(summary.closingBalancePaisa))],
    [],
    ['INCOME CHANNEL / SOURCE', 'AMOUNT (BDT)', 'ENTRIES', 'EXPENSE OFFICE / HEAD', 'AMOUNT (BDT)', 'ENTRIES'],
  ];

  const incomeList = [
    { head: 'Previous Period (Opening Balance)', totalPaisa: summary.openingBalancePaisa, count: 0 },
    ...summary.incomeByHead,
  ];

  for (let i = 0; i < maxRows; i++) {
    const inc = incomeList[i];
    const exp = summary.expenseByHead[i];
    sheetRows.push([
      inc ? inc.head : '',
      inc ? Number(fromPaisa(inc.totalPaisa)) : '',
      inc ? (i === 0 ? 'Carry-fwd' : inc.count) : '',
      exp ? exp.head : '',
      exp ? Number(fromPaisa(exp.totalPaisa)) : '',
      exp ? exp.count : '',
    ]);
  }

  sheetRows.push([]);
  sheetRows.push([
    'TOTAL AVAILABLE INCOME',
    Number(fromPaisa(summary.totalAvailablePaisa)),
    '',
    'TOTAL EXPENSE',
    Number(fromPaisa(summary.periodExpensePaisa)),
    '',
  ]);

  const ws1 = XLSX.utils.aoa_to_sheet(sheetRows);
  ws1['!cols'] = [{ wch: 30 }, { wch: 16 }, { wch: 10 }, { wch: 28 }, { wch: 16 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws1, 'Statement Summary');

   
  const txRows = summary.periodTransactions.map((t) => ({
    Voucher: t.voucherNo,
    Date: t.txDate,
    Type: t.kind.toUpperCase(),
    Department: t.department || '',
    'Channel / Office': t.head,
    'Sub-Category': t.subCategory,
    'Amount (BDT)': Number(fromPaisa(t.amountPaisa)),
    'Method': t.paymentMethod,
    'Reference #': t.referenceNo,
    'From / To (Where)': t.counterparty,
    'Why / Purpose': t.purpose,
    'Status': t.status,
    'Edits': t.editCount,
    'Amount Changed?': t.amountChanged ? 'YES' : 'NO',
    'Last Edit Reason': t.lastEditReason || '',
    'Recorded By': t.createdByName,
  }));
  const ws2 = XLSX.utils.json_to_sheet(txRows);
  XLSX.utils.book_append_sheet(wb, ws2, 'Itemized Ledger');

  XLSX.writeFile(wb, `Pace-IT-Ledger-${summary.from}-to-${summary.to}.xlsx`);
}

export function exportSummaryPdf(summary: PeriodSummary) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  doc.setFontSize(15);
  doc.setTextColor(27, 42, 78);
  doc.text('PACE IT — INCOME & EXPENSE STATEMENT', 14, 16);

  doc.setFontSize(9.5);
  doc.setTextColor(90, 100, 115);
  doc.text(`Period: ${summary.label} (${summary.from} to ${summary.to})`, 14, 22);
  doc.text(`Generated: ${new Date().toLocaleString('en-GB', { timeZone: 'Asia/Dhaka' })} (Asia/Dhaka)`, 14, 27);

  autoTable(doc, {
    startY: 32,
    head: [['Opening Balance', 'Period Income', 'Total Available', 'Total Expense', 'Closing Balance']],
    body: [[
      pdfNum(summary.openingBalancePaisa),
      pdfNum(summary.periodIncomePaisa),
      pdfNum(summary.totalAvailablePaisa),
      pdfNum(summary.periodExpensePaisa),
      pdfNum(summary.closingBalancePaisa),
    ]],
    theme: 'grid',
    styles: { fontSize: 9, cellPadding: 2.5 },
    headStyles: { fillColor: [47, 143, 58] },
  });

  const startY2 = (doc as any).lastAutoTable.finalY + 6;
  const incomeRows = [
    ['Previous Period (Opening)', pdfNum(summary.openingBalancePaisa), '—'],
    ...summary.incomeByHead.map((r) => [r.head, pdfNum(r.totalPaisa), String(r.count)]),
    ['TOTAL AVAILABLE', pdfNum(summary.totalAvailablePaisa), ''],
  ];

  autoTable(doc, {
    startY: startY2,
    head: [['Income Channel / Source', 'Amount', 'Count']],
    body: incomeRows,
    theme: 'striped',
    styles: { fontSize: 8.5, cellPadding: 2 },
    headStyles: { fillColor: [27, 42, 78] },
  });

  const startY3 = (doc as any).lastAutoTable.finalY + 6;
  const expenseRows = [
    ...summary.expenseByHead.map((r) => [r.head, pdfNum(r.totalPaisa), String(r.count)]),
    ['TOTAL EXPENSE', pdfNum(summary.periodExpensePaisa), ''],
  ];

  autoTable(doc, {
    startY: startY3,
    head: [['Expense Office / Head', 'Amount', 'Count']],
    body: expenseRows,
    theme: 'striped',
    styles: { fontSize: 8.5, cellPadding: 2 },
    headStyles: { fillColor: [27, 42, 78] },
  });

  if (summary.periodTransactions.length > 0) {
    doc.addPage('a4', 'landscape');
    doc.setFontSize(12);
    doc.text(`Itemized Ledger (${summary.label})`, 14, 14);
    autoTable(doc, {
      startY: 18,
      head: [['Voucher', 'Date', 'Type', 'Head', 'Amount', 'Method / Ref', 'From / Where', 'Purpose / Why', 'Edits']],
      body: summary.periodTransactions.map((t) => [
        t.voucherNo,
        t.txDate,
        t.kind.toUpperCase(),
        t.head,
        pdfNum(t.amountPaisa),
        `${t.paymentMethod}${t.referenceNo ? ` (${t.referenceNo})` : ''}`,
        t.counterparty,
        t.purpose,
        t.editCount > 0 ? `${t.editCount}x${t.amountChanged ? ' (!)' : ''}` : '0',
      ]),
      theme: 'striped',
      styles: { fontSize: 7.5, cellPadding: 1.8 },
      headStyles: { fillColor: [47, 143, 58] },
    });
  }

  doc.save(`Pace-IT-Statement-${summary.from}-to-${summary.to}.pdf`);
}

export function exportTransactionsExcel(rows: LedgerTransaction[], label = 'Ledger') {
  const wb = XLSX.utils.book_new();
  const data = rows.map((t) => ({
    Voucher: t.voucherNo,
    Date: t.txDate,
    Type: t.kind.toUpperCase(),
    Department: t.department || '',
    'Channel / Office': t.head,
    'Sub-Category': t.subCategory,
    'Amount (BDT)': Number(fromPaisa(t.amountPaisa)),
    Method: t.paymentMethod,
    'Ref / Cheque / ATM #': t.referenceNo,
    'From / Where Spent': t.counterparty,
    'Why / Purpose': t.purpose,
    Status: t.status,
    Edits: t.editCount,
    'Amount Changed': t.amountChanged ? 'YES' : 'NO',
    'Last Edit Reason': t.lastEditReason || '',
    'Created By': t.createdByName,
  }));
  const ws = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, 'Transactions');
  XLSX.writeFile(wb, `Pace-IT-${label.replace(/[^\w\-]+/g, '_')}.xlsx`);
}

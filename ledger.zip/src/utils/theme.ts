import { useSyncExternalStore } from 'react';

export type Theme = 'light' | 'dark';

const FADE_MS = 160;

export function initialTheme(): Theme {
  try {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

let current: Theme =
  typeof document !== 'undefined' && document.documentElement.classList.contains('dark') ? 'dark' : 'light';
const listeners = new Set<() => void>();
let fadeTimer = 0;

export function getTheme(): Theme {
  return current;
}

function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function useTheme(): Theme {
  return useSyncExternalStore(subscribe, getTheme, getTheme);
}

export function applyTheme(t: Theme): void {
  if (t === current) return;
  current = t;
  const root = document.documentElement;
  const animate = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (animate) {
    root.classList.add('theme-fade');
    window.clearTimeout(fadeTimer);
    fadeTimer = window.setTimeout(() => root.classList.remove('theme-fade'), FADE_MS + 40);
  }
  root.classList.toggle('dark', t === 'dark');
  listeners.forEach((fn) => fn());
}

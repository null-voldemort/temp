import type {
  ActivityEvent,
  AdminUserSummary,
  AuditChainEntry,
  ChainVerificationResult,
  DepartmentRecord,
  Employee,
  EmployeeLoan,
  EmployeeAdvance,
  FundSource,
  LedgerHead,
  LedgerTransaction,
  LoanRepayment,
  PeriodLock,
  RentCategory,
  RentItem,
  RentPayment,
  SalaryPayment,
  SecurityEvent,
  TxCategoryGroup,
  UserRole,
} from '../types';
import { getDeviceId, signOut } from './auth';
import { createCloudSyncRefreshers, type CloudRefreshCallback } from './cloudSync';

async function authFetch(path: string, options: RequestInit = {}) {
  const headers = {
    'Content-Type': 'application/json',
    'X-Device-Id': getDeviceId(),
    ...(options.headers || {}),
  };
  const res = await fetch(path, { ...options, headers, credentials: 'include' });
  if (!res.ok) {
    if (res.status === 503) {
      try {
        const body = await res.clone().json();
        if (body?.maintenance) window.dispatchEvent(new CustomEvent('pace-maintenance', { detail: { on: true } }));
      } catch {}
    }
    if (res.status === 401) {
      try { await signOut(); } catch {}
    }
    let msg = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      if (data.error) msg = data.error;
    } catch {}
    throw new Error(msg);
  }
  return res.json();
}

export async function loadTransactions(): Promise<LedgerTransaction[]> {
  return authFetch('/api/transactions');
}

export async function loadFundSources(): Promise<FundSource[]> {
  return authFetch('/api/fund-sources');
}

export async function createFundSource(name: string): Promise<FundSource> {
  return authFetch('/api/fund-sources', { method: 'POST', body: JSON.stringify({ name }) });
}

export async function updateFundSource(id: string, payload: { name?: string; active?: boolean }): Promise<FundSource> {
  return authFetch(`/api/fund-sources/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export interface SaveTxPayload {
  kind: 'income' | 'expense';
  txDate: string;
  amount: string;
  department: string;
  head: string;
  subCategory: string;
  paymentMethod: string;
  referenceNo: string;
  counterparty: string;
  counterpartyPhone?: string;
  purpose: string;
  notes?: string;
  employeeId?: string;
  employeeName?: string;
  categoryGroup?: TxCategoryGroup;
  fundSourceId: string;
  reason?: string;
  receipt?: { name: string; data: string };
}

export async function createTransaction(payload: SaveTxPayload): Promise<LedgerTransaction> {
  return authFetch('/api/transactions', { method: 'POST', body: JSON.stringify(payload) });
}

export async function editTransaction(id: string, payload: SaveTxPayload): Promise<LedgerTransaction> {
  return authFetch(`/api/transactions/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export async function verifyOrFlagTransaction(
  id: string,
  status: 'verified' | 'flagged',
  note: string,
): Promise<LedgerTransaction> {
  return authFetch(`/api/transactions/${encodeURIComponent(id)}/verify`, {
    method: 'POST',
    body: JSON.stringify({ status, note }),
  });
}

export async function voidTransaction(id: string, reason: string): Promise<void> {
  await authFetch(`/api/transactions/${encodeURIComponent(id)}/void`, { method: 'POST', body: JSON.stringify({ reason }) });
}

export async function restoreTransaction(id: string): Promise<void> {
  await authFetch(`/api/transactions/${encodeURIComponent(id)}/restore`, { method: 'POST' });
}

export async function loadEmployees(): Promise<Employee[]> {
  return authFetch('/api/employees');
}

export async function createEmployee(payload: {
  code?: string;
  name: string;
  role: string;
  department: string;
  branch: string;
  phone: string;
  email?: string;
  monthlySalary?: string;
  joinedDate?: string;
  notes?: string;
  photoUrl?: string;
}): Promise<Employee> {
  return authFetch('/api/employees', { method: 'POST', body: JSON.stringify(payload) });
}

export async function updateEmployee(
  id: string,
  payload: {
    name?: string;
    role?: string;
    department?: string;
    branch?: string;
    phone?: string;
    email?: string;
    monthlySalary?: string;
    joinedDate?: string;
    active?: boolean;
    notes?: string;
    photoUrl?: string;
  },
): Promise<Employee> {
  return authFetch(`/api/employees/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export async function loadAdvances(): Promise<EmployeeAdvance[]> {
  return authFetch('/api/advances');
}

export async function createSalaryAdvance(payload: {
  employeeId: string;
  monthKey?: string;
  issuedDate: string;
  amount: string;
  department: string;
  fundSourceId: string;
  paymentMethod: string;
  purpose: string;
}): Promise<EmployeeAdvance> {
  return authFetch('/api/advances', { method: 'POST', body: JSON.stringify(payload) });
}

export async function deleteSalaryAdvance(id: string): Promise<void> {
  await authFetch(`/api/advances/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function loadSalaries(monthKey?: string): Promise<SalaryPayment[]> {
  const qs = monthKey ? `?monthKey=${encodeURIComponent(monthKey)}` : '';
  return authFetch(`/api/salaries${qs}`);
}

export async function paySalary(payload: {
  employeeId: string;
  monthKey: string;
  paidDate: string;
  baseSalary: string;
  payAmount?: string;
  bonus?: string;
  otherDeduction?: string;
  paymentMethod: string;
  referenceNo?: string;
  department: string;
  head?: string;
  fundSourceId: string;
  notes?: string;
  receipt?: { name: string; data: string };
}): Promise<{ payment: SalaryPayment }> {
  return authFetch('/api/salaries/pay', { method: 'POST', body: JSON.stringify(payload) });
}

export async function deleteSalaryPayment(id: string): Promise<void> {
  await authFetch(`/api/salaries/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function loadLoans(): Promise<EmployeeLoan[]> {
  return authFetch('/api/loans');
}

export async function issueLoan(payload: {
  employeeId: string;
  issuedDate: string;
  amount: string;
  monthlyInstallment?: string;
  paymentMethod: string;
  referenceNo?: string;
  department: string;
  head?: string;
  fundSourceId: string;
  purpose: string;
  receipt?: { name: string; data: string };
}): Promise<{ loan: EmployeeLoan }> {
  return authFetch('/api/loans', { method: 'POST', body: JSON.stringify(payload) });
}

export async function deleteLoan(id: string): Promise<void> {
  await authFetch(`/api/loans/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function repayLoan(
  id: string,
  payload: {
    paidDate: string;
    amount: string;
    paymentMethod: string;
    referenceNo?: string;
    department: string;
    head?: string;
    fundSourceId: string;
    note?: string;
    receipt?: { name: string; data: string };
  },
): Promise<{ loan: EmployeeLoan; repayment: LoanRepayment }> {
  return authFetch(`/api/loans/${encodeURIComponent(id)}/repay`, { method: 'POST', body: JSON.stringify(payload) });
}

export async function deleteLoanRepayment(loanId: string, repaymentId: string): Promise<{ ok: boolean; loan: EmployeeLoan }> {
  return authFetch(`/api/loans/${encodeURIComponent(loanId)}/repayments/${encodeURIComponent(repaymentId)}`, {
    method: 'DELETE',
  });
}

export async function loadHeads(): Promise<LedgerHead[]> {
  return authFetch('/api/heads');
}

export async function saveHead(payload: {
  kind: 'income' | 'expense';
  name: string;
  description?: string;
  active?: boolean;
}): Promise<LedgerHead> {
  return authFetch('/api/heads', { method: 'POST', body: JSON.stringify(payload) });
}

export async function renameHead(
  id: string,
  payload: { name: string; description?: string },
): Promise<LedgerHead> {
  return authFetch(`/api/heads/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export async function loadDepartments(): Promise<DepartmentRecord[]> {
  return authFetch('/api/departments');
}

export async function saveDepartment(payload: {
  name: string;
  description?: string;
  active?: boolean;
}): Promise<DepartmentRecord> {
  return authFetch('/api/departments', { method: 'POST', body: JSON.stringify(payload) });
}

export async function renameDepartment(
  id: string,
  payload: { name: string; description?: string },
): Promise<DepartmentRecord> {
  return authFetch(`/api/departments/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export async function loadRentItems(): Promise<RentItem[]> {
  return authFetch('/api/rent-items');
}

export async function createRentItem(payload: {
  sl?: number;
  name: string;
  category: RentCategory;
  monthlyAmount: string;
  urgentAmount?: string;
  department: string;
  notes?: string;
  active?: boolean;
}): Promise<RentItem> {
  return authFetch('/api/rent-items', { method: 'POST', body: JSON.stringify(payload) });
}

export async function updateRentItem(
  id: string,
  payload: {
    sl?: number;
    name?: string;
    category?: RentCategory;
    monthlyAmount?: string;
    urgentAmount?: string;
    department?: string;
    notes?: string;
    active?: boolean;
  },
): Promise<RentItem> {
  return authFetch(`/api/rent-items/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export async function deleteRentItem(id: string): Promise<void> {
  await authFetch(`/api/rent-items/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function loadRentPayments(monthKey?: string): Promise<RentPayment[]> {
  const qs = monthKey ? `?monthKey=${encodeURIComponent(monthKey)}` : '';
  return authFetch(`/api/rent-payments${qs}`);
}

export async function recordRentPayment(payload: {
  rentItemId: string;
  monthKey: string;
  paidDate: string;
  amount: string;
  department: string;
  fundSourceId: string;
  paymentMethod: string;
  referenceNo?: string;
  notes?: string;
  receipt?: { name: string; data: string };
}): Promise<RentPayment> {
  return authFetch('/api/rent-payments', { method: 'POST', body: JSON.stringify(payload) });
}

export async function deleteRentPayment(id: string): Promise<void> {
  await authFetch(`/api/rent-payments/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function loadPeriodLocks(): Promise<PeriodLock[]> {
  return authFetch('/api/locks');
}

export async function lockPeriod(periodKey: string, note: string): Promise<PeriodLock> {
  return authFetch('/api/locks', { method: 'POST', body: JSON.stringify({ periodKey, note }) });
}

export async function unlockPeriod(periodKey: string, reason: string, password: string): Promise<void> {
  await authFetch(`/api/locks/${encodeURIComponent(periodKey)}/unlock`, {
    method: 'POST',
    body: JSON.stringify({ reason, password }),
  });
}

export async function loadAuditChain(): Promise<AuditChainEntry[]> {
  return authFetch('/api/audit');
}

export async function verifyAuditChain(): Promise<ChainVerificationResult> {
  return authFetch('/api/audit/verify');
}

export async function loadActivity(): Promise<ActivityEvent[]> {
  return authFetch('/api/activity');
}

export async function loadUserAvatars(): Promise<Record<string, string>> {
  return authFetch('/api/auth/avatars');
}

export async function listUsers(): Promise<AdminUserSummary[]> {
  return authFetch('/api/admin/users');
}

export async function createUserAccount(
  _token: string,
  username: string,
  password: string,
  displayName: string,
  role: UserRole = 'user',
): Promise<AdminUserSummary> {
  return authFetch('/api/admin/users', { method: 'POST', body: JSON.stringify({ username, password, displayName, role }) });
}

export async function adminUpdateUser(
  id: string,
  payload: { username?: string; displayName?: string; role?: UserRole; phoneNumber?: string; email?: string },
): Promise<AdminUserSummary> {
  return authFetch(`/api/admin/users/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
}

export async function disableUserAccount(_token: string, id: string, disabled: boolean): Promise<void> {
  await authFetch(`/api/admin/users/${encodeURIComponent(id)}/disabled`, { method: 'PATCH', body: JSON.stringify({ disabled }) });
}

export async function resetUserPassword(id: string, password: string): Promise<void> {
  await authFetch(`/api/admin/users/${encodeURIComponent(id)}/reset-password`, { method: 'POST', body: JSON.stringify({ password }) });
}

export async function loadBin(): Promise<{ transactions: LedgerTransaction[] }> {
  return authFetch('/api/admin/bin');
}

export async function loadSecurityLog(): Promise<SecurityEvent[]> {
  return authFetch('/api/admin/security-events');
}

export async function downloadFullBackup(): Promise<void> {
  const res = await fetch('/api/admin/backup', { credentials: 'include' });
  if (!res.ok) throw new Error('Could not export backup.');
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `pace-it-ledger-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export async function restoreFullBackup(backup: unknown, password: string): Promise<void> {
  await authFetch('/api/admin/restore', { method: 'POST', body: JSON.stringify({ backup, password }) });
}

export async function wipeDatabase(
  password: string,
  confirmText: string,
  includeUsers: boolean,
): Promise<{ ok: boolean; factoryReset: boolean }> {
  return authFetch('/api/admin/wipe', {
    method: 'POST',
    body: JSON.stringify({ password, confirmText, includeUsers }),
  });
}

export function subscribeToCloud(callbacks: {
  transactions?: CloudRefreshCallback;
  heads?: CloudRefreshCallback;
  departments?: CloudRefreshCallback;
  locks?: CloudRefreshCallback;
  audit?: CloudRefreshCallback;
  activity?: CloudRefreshCallback;
  employees?: CloudRefreshCallback;
  salaries?: CloudRefreshCallback;
  loans?: CloudRefreshCallback;
  advances?: CloudRefreshCallback;
  fundSources?: CloudRefreshCallback;
  rentItems?: CloudRefreshCallback;
  rentPayments?: CloudRefreshCallback;
  maintenance?: (state: { on: boolean; since?: number }) => void;
}) {
  const sync = createCloudSyncRefreshers({
    ...callbacks,
    fetchStatus: () => authFetch('/api/status'),
  });

  let closed = false;
  let es: EventSource | null = null;
  let reconnectTimer: number | null = null;
  let debounceTimer: number | null = null;

  const scheduleRefresh = () => {
    if (debounceTimer) window.clearTimeout(debounceTimer);
    debounceTimer = window.setTimeout(() => { void sync.refreshAll(); }, 250);
  };

  const connect = () => {
    if (closed) return;
    try {
      es = new EventSource('/api/events', { withCredentials: true });
      es.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg?.type === 'maintenance' && msg?.payload) {
            callbacks.maintenance?.({ on: Boolean(msg.payload.on), since: msg.payload.since });
            return;
          }
          scheduleRefresh();
        } catch {
          scheduleRefresh();
        }
      };
      es.onerror = () => {
        es?.close();
        es = null;
        if (!closed && !reconnectTimer) {
          reconnectTimer = window.setTimeout(() => {
            reconnectTimer = null;
            connect();
          }, 4000);
        }
      };
    } catch {}
  };

  connect();
  const poll = window.setInterval(() => {
    if (!document.hidden) void sync.refreshAll();
  }, 30000);

  return () => {
    closed = true;
    sync.dispose();
    if (es) es.close();
    if (reconnectTimer) window.clearTimeout(reconnectTimer);
    if (debounceTimer) window.clearTimeout(debounceTimer);
    window.clearInterval(poll);
  };
}

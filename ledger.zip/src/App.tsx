import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type {
  ActivityEvent,
  AppUser,
  AuditChainEntry,
  ChainVerificationResult,
  DepartmentRecord,
  Employee,
  EmployeeLoan,
  EmployeeAdvance,
  FundSource,
  LedgerHead,
  LedgerKind,
  LedgerTransaction,
  PeriodLock,
  RentItem,
  RentPayment,
  SalaryPayment,
} from './types';
import { type LedgerView } from './components/Sidebar';
import { AppShell } from './components/AppShell';
import { Dashboard } from './components/Dashboard';
import { StatementSheet } from './components/StatementSheet';
import { TransactionsLedger } from './components/TransactionsLedger';
import { RentTab } from './components/RentTab';
import { EmployeesTab } from './components/EmployeesTab';
import { EmployeeProfileModal } from './components/EmployeeProfileModal';
import { SalaryTab } from './components/SalaryTab';
import { LoansTab } from './components/LoansTab';
import { AuditIntegrityTab } from './components/AuditIntegrityTab';
import { TransactionModal } from './components/TransactionModal';
import { FundsTab } from './components/FundsTab';
import { TransactionDetailModal } from './components/TransactionDetailModal';
import { MaintenanceOverlay } from './components/MaintenanceOverlay';
import {
  loadActivity,
  loadAuditChain,
  loadDepartments,
  loadEmployees,
  loadFundSources,
  loadAdvances,
  loadHeads,
  loadLoans,
  loadPeriodLocks,
  loadRentItems,
  loadRentPayments,
  loadSalaries,
  loadTransactions,
  loadUserAvatars,
  subscribeToCloud,
  verifyAuditChain,
} from './utils/cloud';
import { computeEmployeeSpendStats } from './utils/ledger';
import { changePassword, getCurrentUser, updatePreferences } from './utils/auth';
import { hideSplash } from './utils/splash';
import { applyTheme, getTheme, type Theme } from './utils/theme';
import { createLatestSaver } from './utils/latestSaver';
import { lazyNamed } from './utils/lazyNamed';

const ActivityModal = lazyNamed(() => import('./components/ActivityModal'), 'ActivityModal');
const AdminPanel = lazyNamed(() => import('./components/AdminPanel'), 'AdminPanel');
const BackupModal = lazyNamed(() => import('./components/BackupModal'), 'BackupModal');
const ChangePasswordModal = lazyNamed(() => import('./components/ChangePasswordModal'), 'ChangePasswordModal');
const HeadsModal = lazyNamed(() => import('./components/HeadsModal'), 'HeadsModal');
const ProfileModal = lazyNamed(() => import('./components/ProfileModal'), 'ProfileModal');

const VIEWS: LedgerView[] = ['home', 'ledger', 'sheet', 'rent', 'employees', 'salary', 'loans', 'funds', 'audit'];

interface AppProps {
  currentUser: AppUser;
  onLock: () => void;
}

export default function App({ currentUser, onLock }: AppProps) {
  const [user, setUser] = useState<AppUser>(currentUser);
  useEffect(() => setUser(currentUser), [currentUser]);

  const isAdmin = user.role === 'admin';

  const [currentView, setCurrentView] = useState<LedgerView>('home');

  const lastUserIdRef = useRef(user.id);
  useEffect(() => {
    if (lastUserIdRef.current === user.id) return;
    lastUserIdRef.current = user.id;
    setCurrentView('home');
  }, [user.id]);

  const [transactions, setTransactions] = useState<LedgerTransaction[]>([]);
  const [heads, setHeads] = useState<LedgerHead[]>([]);
  const [departments, setDepartments] = useState<DepartmentRecord[]>([]);
  const [locks, setLocks] = useState<PeriodLock[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [salaries, setSalaries] = useState<SalaryPayment[]>([]);
  const [loans, setLoans] = useState<EmployeeLoan[]>([]);
  const [advances, setAdvances] = useState<EmployeeAdvance[]>([]);
  const [rentItems, setRentItems] = useState<RentItem[]>([]);
  const [rentPayments, setRentPayments] = useState<RentPayment[]>([]);
  const [fundSources, setFundSources] = useState<FundSource[]>([]);
  const [audit, setAudit] = useState<AuditChainEntry[]>([]);
  const [activity, setActivity] = useState<ActivityEvent[]>([]);
  const [avatars, setAvatars] = useState<Record<string, string>>({});
  const [verification, setVerification] = useState<ChainVerificationResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [maintenance, setMaintenance] = useState<{ on: boolean; since?: number }>({ on: false });

  useEffect(() => {
    if (!loading) hideSplash();
  }, [loading]);

  const [txModal, setTxModal] = useState<{
    open: boolean;
    kind: LedgerKind;
    head?: string;
    editing: LedgerTransaction | null;
    duplicating: LedgerTransaction | null;
  }>({
    open: false,
    kind: 'expense',
    editing: null,
    duplicating: null,
  });
  const [detailTxId, setDetailTxId] = useState<string | null>(null);
  const [profileEmpId, setProfileEmpId] = useState<string | null>(null);
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isHeadsOpen, setIsHeadsOpen] = useState(false);
  const [isActivityOpen, setIsActivityOpen] = useState(false);
  const [isBackupOpen, setIsBackupOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isPasswordOpen, setIsPasswordOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((cur) => (cur === msg ? null : cur)), 2800);
  }, []);

  useEffect(() => {
    if (user.theme) applyTheme(user.theme);
  }, [user.theme]);

  const saveTheme = useMemo(
    () => createLatestSaver<Theme>(updatePreferences, (e) => showToast((e as Error)?.message || 'Could not save theme preference')),
    [showToast],
  );
  const handleToggleTheme = useCallback(() => {
    const next: Theme = getTheme() === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    saveTheme(next);
  }, [saveTheme]);

  const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

  const refreshTransactions = useCallback(async () => {
    try {
      const d = await loadTransactions();
      setTransactions((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshHeads = useCallback(async () => {
    try {
      const d = await loadHeads();
      setHeads((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshDepartments = useCallback(async () => {
    try {
      const d = await loadDepartments();
      setDepartments((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshLocks = useCallback(async () => {
    try {
      const d = await loadPeriodLocks();
      setLocks((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshEmployees = useCallback(async () => {
    try {
      const d = await loadEmployees();
      setEmployees((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshSalaries = useCallback(async () => {
    try {
      const d = await loadSalaries();
      setSalaries((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshLoans = useCallback(async () => {
    try {
      const d = await loadLoans();
      setLoans((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshAdvances = useCallback(async () => {
    try {
      const d = await loadAdvances();
      setAdvances((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshRentItems = useCallback(async () => {
    try {
      const d = await loadRentItems();
      setRentItems((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshRentPayments = useCallback(async () => {
    try {
      const d = await loadRentPayments();
      setRentPayments((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshFundSources = useCallback(async () => {
    try {
      const d = await loadFundSources();
      setFundSources((prev) => (same(prev, d) ? prev : d));
    } catch {   }
  }, []);

  const refreshAudit = useCallback(async () => {
    try {
      const [chain, check] = await Promise.all([loadAuditChain(), verifyAuditChain()]);
      setAudit((prev) => (same(prev, chain) ? prev : chain));
      setVerification(check);
    } catch {   }
  }, []);

  const refreshActivity = useCallback(async () => {
    try {
      const [act, av] = await Promise.all([loadActivity(), loadUserAvatars().catch(() => ({}))]);
      setActivity((prev) => (same(prev, act) ? prev : act));
      setAvatars((prev) => (same(prev, av) ? prev : av));
    } catch {   }
  }, []);

  const refreshAll = useCallback(async () => {
    await Promise.all([
      refreshTransactions(),
      refreshHeads(),
      refreshDepartments(),
      refreshLocks(),
      refreshEmployees(),
      refreshSalaries(),
      refreshLoans(),
      refreshAdvances(),
      refreshRentItems(),
      refreshRentPayments(),
      refreshFundSources(),
      refreshAudit(),
      refreshActivity(),
    ]);
  }, [
    refreshTransactions,
    refreshHeads,
    refreshDepartments,
    refreshLocks,
    refreshEmployees,
    refreshSalaries,
    refreshLoans,
    refreshAdvances,
    refreshRentItems,
    refreshRentPayments,
    refreshFundSources,
    refreshAudit,
    refreshActivity,
  ]);

  useEffect(() => {
    let alive = true;
    refreshAll()
      .catch((e: any) => {
        if (alive) showToast(e?.message || 'Could not load ledger data');
      })
      .finally(() => {
        if (alive) setLoading(false);
      });

    const onMaintenance = (m: { on: boolean; since?: number }) => {
      if (!alive) return;
      setMaintenance((prev) => {
        if (prev.on && !m.on) void refreshAll();
        return m.on ? { on: true, since: m.since ?? prev.since ?? Date.now() } : { on: false };
      });
    };
    const onBlocked = () => onMaintenance({ on: true, since: Date.now() });
    window.addEventListener('pace-maintenance', onBlocked);

    const unsubscribe = subscribeToCloud({
      transactions: refreshTransactions,
      heads: refreshHeads,
      departments: refreshDepartments,
      locks: refreshLocks,
      employees: refreshEmployees,
      salaries: refreshSalaries,
      loans: refreshLoans,
      advances: refreshAdvances,
      rentItems: refreshRentItems,
      rentPayments: refreshRentPayments,
      fundSources: refreshFundSources,
      audit: refreshAudit,
      activity: refreshActivity,
      maintenance: onMaintenance,
    });

    return () => {
      alive = false;
      window.removeEventListener('pace-maintenance', onBlocked);
      unsubscribe();
    };
  }, [
    refreshAll,
    refreshTransactions,
    refreshHeads,
    refreshDepartments,
    refreshLocks,
    refreshEmployees,
    refreshSalaries,
    refreshLoans,
    refreshAdvances,
    refreshRentItems,
    refreshRentPayments,
    refreshFundSources,
    refreshAudit,
    refreshActivity,
    showToast,
  ]);

  const detailTx = useMemo(
    () => (detailTxId ? transactions.find((t) => t.id === detailTxId) || null : null),
    [detailTxId, transactions],
  );

  const profileEmp = useMemo(
    () => (profileEmpId ? employees.find((e) => e.id === profileEmpId) || null : null),
    [profileEmpId, employees],
  );

  const employeeStatsMap = useMemo(() => {
    const list = computeEmployeeSpendStats(employees, transactions, loans, salaries);
    return new Map(list.map((s) => [s.employee.id, s]));
  }, [employees, transactions, loans, salaries]);

  const flaggedCount = useMemo(
    () => transactions.filter((t) => !t.deletedAt && (t.status === 'flagged' || t.amountChanged)).length,
    [transactions],
  );
  const activeLoansCount = useMemo(
    () => loans.filter((l) => l.status === 'active').length,
    [loans],
  );

  const openNewTx = (kind: LedgerKind, head?: string) => {
    setTxModal({ open: true, kind, head, editing: null, duplicating: null });
  };

  const openEditTx = (tx: LedgerTransaction) => {
    setTxModal({ open: true, kind: tx.kind, editing: tx, duplicating: null });
  };

  const openDuplicateTx = (tx: LedgerTransaction) => {
    setTxModal({ open: true, kind: tx.kind, editing: null, duplicating: tx });
  };

  const activeView: LedgerView = VIEWS.includes(currentView) ? currentView : 'home';

  if (loading) return null;

  return (
    <div className="min-h-screen bg-[#eef8f1] text-[#1b2a4e] flex flex-col">
      {maintenance.on && <MaintenanceOverlay since={maintenance.since} />}

      <AppShell
        onGoHome={() => setCurrentView('home')}
        currentView={activeView}
        onNavigate={(v) => setCurrentView(v)}
        userName={user.displayName}
        userRole={user.role}
        userPhotoUrl={user.photoUrl}
        onOpenProfile={() => setIsProfileOpen(true)}
        onLogout={onLock}
        onOpenBackup={() => setIsBackupOpen(true)}
        onOpenActivity={() => setIsActivityOpen(true)}
        onChangePassword={() => setIsPasswordOpen(true)}
        onOpenHeads={() => setIsHeadsOpen(true)}
        onOpenAdmin={isAdmin ? () => setIsAdminOpen(true) : undefined}
        flaggedCount={flaggedCount}
        activeLoansCount={activeLoansCount}
        onToggleDark={handleToggleTheme}
      >
          <main key={activeView} className="flex-1 min-w-0 page-switch-in">
            {activeView === 'home' && (
              <Dashboard
                transactions={transactions}
                heads={heads}
                employees={employees}
                loans={loans}
                salaries={salaries}
                verification={verification}
                userName={user.displayName}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onOpenEmployee={(emp) => setProfileEmpId(emp.id)}
                onGoSheet={() => setCurrentView('sheet')}
                onGoLedger={() => setCurrentView('ledger')}
                onGoEmployees={() => setCurrentView('employees')}
                onGoLoans={() => setCurrentView('loans')}
                onGoAudit={() => setCurrentView('audit')}
              />
            )}

            {activeView === 'ledger' && (
              <TransactionsLedger
                transactions={transactions}
                heads={heads}
                departments={departments}
                employees={employees}
                fundSources={fundSources}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onAddTx={(kind) => openNewTx(kind)}
                onEditTx={openEditTx}
                onDuplicateTx={openDuplicateTx}
                onOpenEmployee={(emp) => setProfileEmpId(emp.id)}
                onQuickSaved={() => void refreshAll()}
                onToast={showToast}
              />
            )}

            {activeView === 'sheet' && (
              <StatementSheet
                transactions={transactions}
                heads={heads}
                locks={locks}
                isAdmin={isAdmin}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onAddTx={(kind, head) => openNewTx(kind, head)}
                onEditTx={openEditTx}
                onDuplicateTx={openDuplicateTx}
                onLocksChanged={() => { void refreshLocks(); void refreshAudit(); void refreshActivity(); }}
                onToast={showToast}
              />
            )}

            {activeView === 'rent' && (
              <RentTab
                rentItems={rentItems}
                rentPayments={rentPayments}
                departments={departments}
                fundSources={fundSources}
                transactions={transactions}
                isAdmin={isAdmin}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onChanged={() => void refreshAll()}
                onToast={showToast}
              />
            )}

            {activeView === 'employees' && (
              <EmployeesTab
                employees={employees}
                transactions={transactions}
                loans={loans}
                salaries={salaries}
                heads={heads}
                departments={departments}
                isAdmin={isAdmin}
                onOpenEmployee={(emp) => setProfileEmpId(emp.id)}
                onChanged={() => void refreshAll()}
                onToast={showToast}
                editingEmployee={editingEmp}
                onClearEditingEmployee={() => setEditingEmp(null)}
              />
            )}

            {activeView === 'salary' && (
              <SalaryTab
                employees={employees}
                salaries={salaries}
                loans={loans}
                advances={advances}
                fundSources={fundSources}
                heads={heads}
                departments={departments}
                transactions={transactions}
                isAdmin={isAdmin}
                onOpenEmployee={(emp) => setProfileEmpId(emp.id)}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onChanged={() => void refreshAll()}
                onToast={showToast}
              />
            )}

            {activeView === 'loans' && (
              <LoansTab
                employees={employees}
                loans={loans}
                fundSources={fundSources}
                heads={heads}
                departments={departments}
                transactions={transactions}
                isAdmin={isAdmin}
                onOpenEmployee={(emp) => setProfileEmpId(emp.id)}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onChanged={() => void refreshAll()}
                onToast={showToast}
              />
            )}

            {activeView === 'funds' && (
              <FundsTab
                sources={fundSources}
                transactions={transactions}
                isAdmin={isAdmin}
                onChanged={() => void refreshAll()}
                onToast={showToast}
              />
            )}

            {activeView === 'audit' && (
              <AuditIntegrityTab
                audit={audit}
                verification={verification}
                locks={locks}
                transactions={transactions}
                isAdmin={isAdmin}
                onVerifyNow={refreshAudit}
                onLocksChanged={() => { void refreshLocks(); void refreshAudit(); void refreshActivity(); }}
                onOpenTx={(tx) => setDetailTxId(tx.id)}
                onToast={showToast}
              />
            )}
          </main>
      </AppShell>

      <TransactionModal
        isOpen={txModal.open}
        onClose={() => setTxModal((m) => ({ ...m, open: false, editing: null, duplicating: null }))}
        initialKind={txModal.kind}
        initialHead={txModal.head}
        editingTx={txModal.editing}
        duplicatingTx={txModal.duplicating}
        heads={heads}
        departments={departments}
        employees={employees}
        fundSources={fundSources}
        recentTransactions={transactions}
        isAdmin={isAdmin}
        onSaved={(saved, isEdit) => {
          showToast(isEdit ? `${saved.voucherNo} updated (edit logged)` : `${saved.voucherNo} saved`);
          void refreshAll();
        }}
      />

      <TransactionDetailModal
        tx={detailTx}
        isAdmin={isAdmin}
        onClose={() => setDetailTxId(null)}
        onEdit={(tx) => openEditTx(tx)}
        onDuplicate={(tx) => openDuplicateTx(tx)}
        onChanged={() => void refreshAll()}
        onToast={showToast}
      />

      <EmployeeProfileModal
        employee={profileEmp}
        stat={profileEmp ? employeeStatsMap.get(profileEmp.id) : undefined}
        transactions={transactions}
        salaries={salaries}
        loans={loans}
        advances={advances}
        isAdmin={isAdmin}
        onClose={() => setProfileEmpId(null)}
        onEditEmployee={(emp) => {
          setProfileEmpId(null);
          setEditingEmp(emp);
          setCurrentView('employees');
        }}
        onOpenTx={(tx) => setDetailTxId(tx.id)}
      />

      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        currentUser={user}
        onToast={showToast}
        onBinChanged={() => void refreshAll()}
        onUsersChanged={async () => {
          const me = await getCurrentUser();
          if (me) setUser(me);
          void refreshActivity();
        }}
        onFactoryReset={onLock}
      />

      <HeadsModal
        isOpen={isHeadsOpen}
        onClose={() => setIsHeadsOpen(false)}
        heads={heads}
        departments={departments}
        isAdmin={isAdmin}
        onChanged={() => { void refreshHeads(); void refreshActivity(); }}
        onDepartmentsChanged={() => { void refreshDepartments(); void refreshActivity(); }}
        onToast={showToast}
      />

      <ActivityModal
        isOpen={isActivityOpen}
        onClose={() => setIsActivityOpen(false)}
        events={activity}
        avatars={avatars}
      />

      <BackupModal
        isOpen={isBackupOpen}
        onClose={() => setIsBackupOpen(false)}
        isAdmin={isAdmin}
        onRestored={() => void refreshAll()}
        onFactoryReset={onLock}
        onToast={showToast}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        user={user}
        onClose={() => setIsProfileOpen(false)}
        onUpdateUser={(u) => { setUser(u); void refreshActivity(); }}
        onLogout={onLock}
        onChangePassword={() => setIsPasswordOpen(true)}
      />

      <ChangePasswordModal
        isOpen={isPasswordOpen}
        onClose={() => setIsPasswordOpen(false)}
        onSave={async (cur, next) => {
          await changePassword(cur, next);
          setIsPasswordOpen(false);
          showToast('Password updated');
        }}
      />

      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="no-print fixed bottom-5 right-5 z-[110] rounded-2xl bg-[#1b2a4e] text-white px-4 py-3 text-xs font-semibold shadow-xl border border-white/10"
        >
          {toast}
        </div>
      )}
    </div>
  );
}
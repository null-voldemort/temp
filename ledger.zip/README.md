# Pace IT Ledger

Internal finance, employee payroll, loan, and daily expense management application for Pace IT.

## Stack

React 19, Vite, Tailwind CSS 4, Express, Node built-in SQLite (`node:sqlite`), TypeScript.

## Running

```bash
npm install
npm run build
npm start
```

Development mode: `npm run dev`. Type check: `npm run lint`. Tests: `npm test`.
